/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package javasocnet;

import com.mysql.jdbc.jdbc2.optional.MysqlDataSource;
import dao.DAOFactory;
import dao.DriverManagerDAOJDBCFactory;
import dao.StudentDAO;
import dao.StudentDAOJDBC;
import java.sql.Connection;
import java.util.List;
import javax.sql.DataSource;
import model.Student;

/**
 *
 * @author Amdrii
 */
public class JavaSocNet {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

       
        
        DAOFactory daoFactory = DAOFactory.
                getDAOFactory(DAOFactory.ConnTypes.DataSourceJDBC);
        //StudentDAO studDAO = new StudentDAOJDBC(daoFactory);
        StudentDAO studDAO = daoFactory.getStudentDAO();
        
        Student stud1 = new Student();
        stud1.setStudenName("Serg");
        stud1.setStudentYear(3);
        
        //studDAO.create(stud1);
        
        List<Student> list = studDAO.findAll();
        System.out.println(list);
               
    }
}
