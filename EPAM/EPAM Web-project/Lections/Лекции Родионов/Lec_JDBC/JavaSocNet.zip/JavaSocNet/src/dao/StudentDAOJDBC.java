/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import model.Student;

import static dao.DAOJDBCUtil.*;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Amdrii
 */
public class StudentDAOJDBC implements StudentDAO{

    private DAOFactory daoFactory;
    
    public StudentDAOJDBC(DAOFactory daoFactory) {
        this.daoFactory = daoFactory;
    }
    
    @Override
    public Student find(Integer id) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public List<Student> findAll() {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        List<Student> students = new ArrayList<Student>();

        try {
            connection = daoFactory.getConnection();
            preparedStatement = connection.prepareStatement("select * from Student");
            resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                students.add(map(resultSet));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            close(resultSet);
            close(preparedStatement);
            close(connection);            
        }

        return students;
    }

    @Override
    public boolean create(Student student) {
            Connection connection = null;
            PreparedStatement preparedStatement = null;
        try {    
            connection = daoFactory.getConnection();
            preparedStatement = connection.prepareStatement("INSERT INTO Student "
                    + "(name, year) VALUES (?, ?)");
            preparedStatement.setString(1, student.getStudenName());
            preparedStatement.setInt(2, student.getStudentYear());
            return preparedStatement.execute();
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            close(preparedStatement);
            close(connection);  
        }
        return false;
    }

    private Student map(ResultSet resultSet) throws SQLException {
        Student student = new Student();
        student.setSudentID(resultSet.getInt(1));
        student.setStudenName(resultSet.getString(2));
        student.setStudentYear(resultSet.getInt(3));
        return student;
    }
    
}
