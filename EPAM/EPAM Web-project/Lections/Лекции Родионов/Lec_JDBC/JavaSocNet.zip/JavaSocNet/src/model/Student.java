/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author Amdrii
 */
public class Student {
    Integer sudentID;
    String studenName;
    Integer studentYear;

    public String getStudenName() {
        return studenName;
    }

    public void setStudenName(String studenName) {
        this.studenName = studenName;
    }

    public Integer getStudentYear() {
        return studentYear;
    }

    public void setStudentYear(Integer studentYear) {
        this.studentYear = studentYear;
    }

    public Integer getSudentID() {
        return sudentID;
    }

    public void setSudentID(Integer sudentID) {
        this.sudentID = sudentID;
    }

    @Override
    public String toString() {
        return "Student{" + "sudentID=" + sudentID + ", studenName=" + studenName + ", studentYear=" + studentYear + '}'+"\n";
    }
    
    
}
