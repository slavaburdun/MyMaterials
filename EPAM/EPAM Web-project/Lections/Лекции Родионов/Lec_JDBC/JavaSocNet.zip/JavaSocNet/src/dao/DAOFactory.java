/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.sql.Connection;
import java.sql.SQLException;

/**
 *
 * @author Amdrii
 */
public abstract class DAOFactory {
    
    public enum ConnTypes{
        DriverManagerJDBC, DataSourceJDBC
    }

    public static DAOFactory getDAOFactory(ConnTypes connType){
        switch(connType){
            case DriverManagerJDBC:  
                return new DriverManagerDAOJDBCFactory(); 
            case DataSourceJDBC:
                return new DataSourceDAOJDBCFactory();
            default: return null;
        }
    };
       
    public abstract Connection getConnection() throws SQLException;

    public abstract StudentDAO getStudentDAO(); 
    
}
