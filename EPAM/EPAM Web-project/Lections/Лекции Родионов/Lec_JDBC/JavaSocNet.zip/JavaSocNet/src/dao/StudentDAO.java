/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.util.List;
import model.Group;
import model.Student;

/**
 *
 * @author Amdrii
 */
public interface StudentDAO {
    Student find(Integer id);
    List<Student> findAll();
    boolean create(Student student);
    //boolean upadate(Student student);
    //List<Student> findAllInGroup(Integer groupID);
    //List<Student> findAllInGroup(Group group);
    
}
