/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.util.List;
import model.Group;
import model.Student;

/**
 *
 * @author Amdrii
 */
public interface GroupDAO {
    Group find(Integer id);
    List<Group> findAll();
    boolean create(Group group);
    boolean addStudentToGroup(Group group, Student student);
    
}
