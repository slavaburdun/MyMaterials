/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package control.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Amdrii
 */
public class ViewStudent implements Action{

    @Override
    public String execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
        System.out.println(request.getParameter("studid"));        
        request.setAttribute("studid",request.getParameter("studid"));        
        return "ViewStudent";
    }
    
}
