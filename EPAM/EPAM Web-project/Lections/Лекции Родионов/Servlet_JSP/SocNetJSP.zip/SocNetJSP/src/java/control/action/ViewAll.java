/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package control.action;

import dao.DAOFactory;
import dao.StudentDAO;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Amdrii
 */
public class ViewAll implements Action{

    @Override
    public String execute(HttpServletRequest request, 
            HttpServletResponse response) throws Exception {
        DAOFactory daoFactory = DataSourceDAOFactory.getDAOFactory();
        StudentDAO studDAO = daoFactory.getStudentDAO();
        request.setAttribute("students", studDAO.findAll());
        
        return "ViewAll";
    }
    
}
