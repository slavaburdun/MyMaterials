/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

/**
 *
 * @author Amdrii
 */
public class DriverManagerDAOJDBCFactory extends DAOFactory{

//    private static final Properties prop = new Properties();
//
//    static{
//        try {
//            //File file = new File("dao.properties");
//            //System.out.println(file.getCanonicalPath());
//            
//            prop.load(new FileReader("dao.properties"));            
//        } catch (IOException ex) {
//            ex.printStackTrace();
//        }
//    }
        
    @Override
    public Connection getConnection() throws SQLException {
        String driver = "com.mysql.jdbc.Driver"; // prop.getProperty("javabase.jdbc.driver");
        try {
            Class.forName(driver);
        } catch (ClassNotFoundException ex) {
            ex.printStackTrace();
        }
        String url = "jdbc:mysql://localhost:3306/socnet"; // prop.getProperty("javabase.jdbc.url");
        String user = "root"; //prop.getProperty("javabase.jdbc.username");
        String pass = "root"; // prop.getProperty("javabase.jdbc.password");
        return DriverManager.getConnection(url, user, pass);
    }

    @Override
    public StudentDAO getStudentDAO() {
        return new StudentDAOJDBC(this);
    }

    @Override
    public GroupDAO getGroupDAO() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

   
    
}
