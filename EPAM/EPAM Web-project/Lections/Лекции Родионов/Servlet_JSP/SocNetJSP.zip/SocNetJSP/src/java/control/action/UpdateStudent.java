/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package control.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Amdrii
 */
public class UpdateStudent implements Action {

    @Override
    public String execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
        throw new UnsupportedOperationException("Not supported yet.");
    }
    
}
