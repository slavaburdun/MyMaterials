package com.gonchar.sslclient;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PipedReader;
import java.io.PipedWriter;
import java.net.UnknownHostException;
import java.security.KeyStore;
import java.security.SecureRandom;
import java.security.cert.Certificate;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLHandshakeException;
import javax.net.ssl.SSLSession;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.TrustManagerFactory;
import javax.net.ssl.X509TrustManager;

import android.app.Activity;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends Activity
{

	private Button sendButton;
	private Button connectButton;
	private EditText ipText;
	private EditText messageText;
	private EditText logText;

	private PipedWriter outPipe;
	private String ip;
	private String message;
	private SSLThread sslThread;
	private SSLContext sslContext;
	private X509TrustManager Cur_Trust_Manager;
	static final int PORT = 10000;

	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		connectButton = (Button) findViewById(R.id.buttonConnect);
		ipText = (EditText) findViewById(R.id.editTextIP);
		sendButton = (Button) findViewById(R.id.buttonSend);
		messageText = (EditText) findViewById(R.id.editTextMessage);
		logText = (EditText) findViewById(R.id.editTextLog);
		sendButton.setEnabled(false);
		messageText.setEnabled(false);
		connectButton.setOnClickListener(connectServer);
		sendButton.setOnClickListener(sendMessage);
		loadCert();
	}
	
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK) {
			if (connectButton.isEnabled() == false) {
				try {
					connectButton.setEnabled(false);
					messageText.setEnabled(false);
					connectButton.setEnabled(true);
					ipText.setEnabled(true);
					ipText.setText("192.168.1.1");
					ipText.setText("192.168.1.1");
					outPipe.write(1);
					Log.d("Restarting", "thread");
					return true;
				} catch (IOException e) {
					e.printStackTrace();
					return super.onKeyDown(keyCode, event);
				}
			} else {
				Log.d("closing", "app");
				return super.onKeyDown(keyCode, event);
			}
		}
		return super.onKeyDown(keyCode, event);
	}
	
	@Override
	protected void onDestroy() {
		super.onDestroy();
		Log.d("onDestroy", "onDestroy");
	}

	Button.OnClickListener connectServer = new Button.OnClickListener()
	{
		@Override
		public void onClick(View arg0)
		{
			ip = ipText.getText().toString();
			sendButton.setEnabled(true);
			messageText.setEnabled(true);
			connectButton.setEnabled(false);
			ipText.setEnabled(false);
			Log.d("Server ip: ", ip);
			updateLog("Server ip: " + ip);
			sslThread = new SSLThread();
			sslThread.execute();
		}
	};
	
	Button.OnClickListener sendMessage = new Button.OnClickListener()
	{
		@Override
		public void onClick(View arg0)
		{
			message = messageText.getText().toString();
			messageText.setText("");
			try
			{
				outPipe.write(0);
				updateLog("Client: " + message);
			} 
			catch (IOException e)
			{
				e.printStackTrace();
			}
		}
	};
	
	private void loadCert()
	{
		// load text
		try
		{
			// Create a KeyStore containing our trusted CAs
			String keyStoreType = KeyStore.getDefaultType();
			Log.d("ssl_debug", "default keyStore type is: " + keyStoreType);
			KeyStore skeyStore = KeyStore.getInstance(keyStoreType);
			CertificateFactory cf = CertificateFactory.getInstance("X.509");
			InputStream sInput = new BufferedInputStream(getAssets().open("selfSigned.crt"));
			Certificate server_crt;
			try
			{
				server_crt = cf.generateCertificate(sInput);
				Log.d("server ca", ((X509Certificate) server_crt).getSubjectDN().toString());
			} 
			finally
			{
				sInput.close();
			}

			skeyStore.load(null, null);
			skeyStore.setCertificateEntry("ca", server_crt);

			String tmfAlgorithm = TrustManagerFactory.getDefaultAlgorithm();
			TrustManagerFactory tmf = TrustManagerFactory.getInstance(tmfAlgorithm);
			tmf.init(skeyStore);

			X509TrustManager Main_Trust_Manager = null;

			for (TrustManager tm : tmf.getTrustManagers())
			{
				if (tm instanceof X509TrustManager)
				{
					Main_Trust_Manager = (X509TrustManager) tm;
					break;
				}
			}
			Cur_Trust_Manager = Main_Trust_Manager;

			// Create an SSLContext that uses our TrustManager
			sslContext = SSLContext.getInstance("TLS");
			sslContext.init(null, new TrustManager[] { Cur_Trust_Manager },	new SecureRandom());
		} 
		catch (Exception ex)
		{
			ex.printStackTrace();
		} 
	};

	@Override
	public boolean onCreateOptionsMenu(Menu menu)
	{
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item)
	{
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings)
		{
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
	
	/**
	 * Updates logText field
	 * 
	 * @param message
	 */
	private void updateLog(String message)
	{
		if (!message.endsWith("\n"))
		{
			Log.d("With", "n");
			logText.append(message + "\n");
		} 
		else
		{
			Log.d("Without", "n");
			logText.append(message);
		}
	};

	/**
	 * Thread for ssl connection
	 * 
	 * @author iv.gonchar
	 */
	private class SSLThread extends AsyncTask<Void, String, Void>
	{
		private SSLSocketFactory s_factory;
		private SSLSocket socket;
		private BufferedWriter output = null;
		private BufferedReader input = null;
		private PipedReader inPipe;
		private boolean keepGoing;
		private WriteThread wt;

		private class WriteThread extends Thread
		{
			@Override
			public void run()
			{
				Log.d("Starting: ", "WriteThread");

				try
				{
					while (keepGoing)
					{
						int w = inPipe.read();
						if (w == 0)
						{
							Log.d("Client: ", message);
							output.write(message + "\n");
							output.flush();
						} else
						{
							Log.e("Stop run from", "WriteThread");
							keepGoing = false;
						}
					}
				} catch (IOException e)
				{
					Log.e("IOException", "WriteThread");
					e.printStackTrace();
					keepGoing = false;
				} finally
				{
					closeAll();
				}
			}
		}

		public SSLThread()
		{
			try
			{
				outPipe = new PipedWriter();
				inPipe = new PipedReader(outPipe);
				wt = new WriteThread();
			} 
			catch (IOException e)
			{
				Log.e("IOException", "SSLThread: creation");
				e.printStackTrace();
			}
		}

		@Override
		protected Void doInBackground(Void... params)
		{
			keepGoing = true;
			s_factory = sslContext.getSocketFactory();
			try
			{
				socket = (SSLSocket) s_factory.createSocket(ip, PORT);

				HostnameVerifier hv = new HostnameVerifier()
				{
					@Override
					public boolean verify(String hostname, SSLSession session)
					{
						try
						{
							Cur_Trust_Manager.checkServerTrusted(
									(X509Certificate[]) session
											.getPeerCertificates(), session
											.getCipherSuite());
							return true;
						} 
						catch (CertificateException e)
						{
							Log.i("HostnameVerifier- checkServerTrusted",
									"CertificateException - " + e.toString());
						} 
						catch (Exception e)
						{
							Log.i("HostnameVerifier- checkServerTrusted",
									"Exception - " + e.toString());
						}
						return false;
					}
				};
				SSLSession s = socket.getSession();

				// Verify that the certicate hostname is for mail.google.com
				// This is due to lack of SNI support in the current SSLSocket.
				if (!hv.verify(ip, s))
				{
					throw new SSLHandshakeException("Expected " + ip + "found "
							+ s.getPeerPrincipal());
				}

				output = new BufferedWriter(new OutputStreamWriter(
						socket.getOutputStream()));
				input = new BufferedReader(new InputStreamReader(
						socket.getInputStream()));
				wt.start();
				Log.d("WriteThread", "Start");
				while (keepGoing)
				{
					Log.d("Inside", "Loop");
					String m = input.readLine();
					if ((m != null) && (m.length() != 0))
					{
						Log.d("Server", m);
						publishProgress(m);
					}
				}
			} 
			catch (UnknownHostException e)
			{
				Log.e("Error", "UnknownHostException");
				e.printStackTrace();
				keepGoing = false;
			} 
			catch (IOException e)
			{
				Log.e("Error", "IOException");
				e.printStackTrace();
				Log.e("error", e.getMessage());
				keepGoing = false;
			} 
			finally
			{
				closeAll();
			}
			return null;
		}

		@Override
		protected void onProgressUpdate(String... m_arr)
		{
			updateLog("Server: " + m_arr[0]);
		}

		private void closeAll()
		{
			Log.d("Close", "All");
			if (input != null)
			{
				try
				{
					input.close();
				} 
				catch (IOException e)
				{
					e.printStackTrace();
				}
			}

			if (output != null)
			{
				try
				{
					output.close();
				} 
				catch (IOException e)
				{
					e.printStackTrace();
				}
			}
			if (socket != null)
			{
				try
				{
					socket.close();
				} 
				catch (IOException e)
				{
					e.printStackTrace();
				}
			}

			if (inPipe != null)
			{
				try
				{
					inPipe.close();
				} 
				catch (IOException e)
				{
					e.printStackTrace();
				}
			}

			if (outPipe != null)
			{
				try
				{
					outPipe.close();
				} 
				catch (IOException e)
				{
					e.printStackTrace();
				}
			}
		}
	}
}
