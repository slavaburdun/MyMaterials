package com.gonchar;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.PipedInputStream;
import java.io.PipedOutputStream;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.widgets.Label;

public class ServerGUI
{
	/**
	 * window of ssl Server application
	 */
	protected Shell shlSslServer;
	
	/**
	 * Field with messages from client
	 */
	private Text messagesFromClient;

	/**
	 * Field with messages to client
	 */
	private Text messageToClient;

	/**
	 * Instance of ssl server
	 */
	private Server server;
	private Boolean newMessageFromClient = false;
	private String receivedMessages = "";
	private boolean serverStarted = false;
	private MessagesFromClientMonitor messagesFromClientMonitor;

	private PipedInputStream messagesToClientInPipe;
	private PipedOutputStream messagesFromClientOutPipe;
	private PipedInputStream messagesFromClientInPipe;
	private PipedOutputStream messagesToClientOutPipe;

	private class MessagesFromClientMonitor extends Thread
	{
		private PipedInputStream messagesFromClientInputPipe;

		public MessagesFromClientMonitor(
				PipedInputStream messagesFromClientInputPipe)
		{
			this.messagesFromClientInputPipe = messagesFromClientInputPipe;
		}

		@Override
		public void run()
		{
			DataInputStream messagesFromClientDin = new DataInputStream(
					messagesFromClientInputPipe);
			String messageFromClient = null;
			try
			{
				while (true)
				{
					messageFromClient = messagesFromClientDin.readUTF();
					synchronized (newMessageFromClient)
					{
						receivedMessages += messageFromClient + "\n";
						newMessageFromClient = true;
					}
				}
			} 
			catch (IOException e)
			{
				System.out.println("Close messages from client data input stream");
			}
		}
	}

	public static void main(String[] args)
	{
		try
		{
			ServerGUI window = new ServerGUI();
			window.open();
		} 
		catch (Exception e)
		{
			e.printStackTrace(System.out);
		}
	}

	public void open()
	{
		Display display = Display.getDefault();
		createContents();
		shlSslServer.open();
		shlSslServer.layout();
		while (!shlSslServer.isDisposed())
		{
			if (!display.readAndDispatch())
			{
				display.sleep();
			}
			updateText();
		}
		try
		{
			server.stopServer();
			server.join();
		}
		catch (InterruptedException e)
		{
			e.printStackTrace();
		}
	}

	private void updateText()
	{
		synchronized (newMessageFromClient)
		{
			if (newMessageFromClient)
			{
				messagesFromClient.append(receivedMessages);
				receivedMessages = "";
				newMessageFromClient = false;
			}
		}
	}

	/**
	 * @wbp.parser.entryPoint
	 */
	protected void createContents()
	{
		shlSslServer = new Shell();
		shlSslServer.setModified(true);
		shlSslServer.setSize(450, 260);
		shlSslServer.setText("SSL Server");

		final Button startServerButton = new Button(shlSslServer, SWT.PUSH);
		startServerButton.setBounds(350, 200, 90, 30);
		startServerButton.setText("Start");

		messagesFromClient = new Text(shlSslServer, SWT.BORDER | SWT.READ_ONLY
				| SWT.H_SCROLL | SWT.V_SCROLL | SWT.MULTI);
		messagesFromClient.setBounds(27, 80, 410, 105);
		messagesFromClient.setText(receivedMessages);

		Label lblNewLabel = new Label(shlSslServer, SWT.NONE);
		lblNewLabel.setBounds(148, 60, 152, 20);
		lblNewLabel.setText("Messages from client:");

		Button sendMessageToClientButton = new Button(shlSslServer, SWT.NONE);
		sendMessageToClientButton.setBounds(350, 20, 90, 30);
		sendMessageToClientButton.setText("Send");
		sendMessageToClientButton.addSelectionListener(new SelectionListener()
		{
			@Override
			public void widgetSelected(SelectionEvent event)
			{
				if (serverStarted)
				{
					try
					{
						DataOutputStream dout = new DataOutputStream(messagesToClientOutPipe);
						dout.writeUTF(messageToClient.getText() + "\n");
						dout.flush();
						messageToClient.setText("");
					} 
					catch (IOException e)
					{
						e.printStackTrace();
					}
				}
			}

			@Override
			public void widgetDefaultSelected(SelectionEvent arg0)
			{
				
			}
		});

		messageToClient = new Text(shlSslServer, SWT.BORDER);
		messageToClient.setBounds(27, 20, 320, 30);
		startServerButton.addSelectionListener(new SelectionListener()
		{

			@Override
			public void widgetSelected(SelectionEvent event)
			{
				if (!serverStarted)
				{
					serverStarted = true;
					messagesFromClientOutPipe = new PipedOutputStream();
					messagesToClientInPipe = new PipedInputStream();
					try
					{
						messagesFromClientInPipe = new PipedInputStream(
								messagesFromClientOutPipe);
						messagesToClientOutPipe = new PipedOutputStream(
								messagesToClientInPipe);
						server = new Server(messagesFromClientOutPipe,
								messagesToClientInPipe);
						System.out.println("Create Server");
						server.start();
						System.out.println("Start Server");
						messagesFromClientMonitor = new ServerGUI.MessagesFromClientMonitor(
								messagesFromClientInPipe);
						messagesFromClientMonitor.start();
						System.out
								.println("Start messages from client monitor");
					} catch (IOException e)
					{
						e.printStackTrace();
					}
				}
			}

			@Override
			public void widgetDefaultSelected(SelectionEvent arg0)
			{
				
			}
		});
	}

	public void test(Text text, String t)
	{
		text.setText(t);
	}

	public void updateText(String message)
	{
		messagesFromClient.setText(message);
	}
}
