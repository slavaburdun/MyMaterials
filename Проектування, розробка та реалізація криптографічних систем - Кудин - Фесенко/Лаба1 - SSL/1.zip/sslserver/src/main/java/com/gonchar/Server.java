package com.gonchar;

import java.io.*;

import javax.net.ssl.SSLServerSocket;
import javax.net.ssl.SSLServerSocketFactory;
import javax.net.ssl.SSLSession;
import javax.net.ssl.SSLSocket;

public class Server extends Thread
{
	/**
	 * Stream with received messages
	 */
	private DataOutputStream receiveMessagesFromClientDout;
	
	/**
	 * Stream with messages to send
	 */
	private DataInputStream sendMessagesToClientDin;
	
	/**
	 * ssl socket
	 */
	private SSLSocket sslSocket;
	
	/**
	 * Separate thread for receiving messages
	 */
	private Thread receiveMessagesFromClientThread;
	
	/**
	 * Separate thread for sending messages
	 */
	private Thread sendMessagesToClientThread;
	
	/**
	 * Flag controls server shutdown
	 */
	private Boolean stopServer = false;
	
	private final static int PORT = 10000;

	/**
	 * Constructor
	 * 
	 * @param messagesFromClientPipe
	 * @param messagesToClientPipe
	 */
	public Server(PipedOutputStream messagesFromClientPipe,	PipedInputStream messagesToClientPipe)
	{
		receiveMessagesFromClientDout = new DataOutputStream(messagesFromClientPipe);
		sendMessagesToClientDin = new DataInputStream(messagesToClientPipe);
	}

	@Override
	public void run()
	{
		System.setProperty("javax.net.debug", "all");
		//sets path to keyStore
		System.setProperty(
				"javax.net.ssl.keyStore",
				"src/main/resources/Server_CA/server.jks");
		//sets password to keyStore
		System.setProperty("javax.net.ssl.keyStorePassword", "123456");

		SSLServerSocketFactory sslServerSocketFactory = (SSLServerSocketFactory) SSLServerSocketFactory
				.getDefault();
		try (SSLServerSocket sslServerSocket = (SSLServerSocket) sslServerSocketFactory
				.createServerSocket(PORT))
		{

			sslSocket = (SSLSocket) sslServerSocket.accept();
			
			//prints inet address
			System.out.println(sslSocket.getInetAddress());
			
			//receives client's info
			receiveClientInfo();
			receiveMessagesFromClientThread = new Thread(new Runnable()
			{
				@Override
				public void run()
				{
					receiveMessagesFromClient();
				}
			});
			
			sendMessagesToClientThread = new Thread(new Runnable()
			{
				@Override
				public void run()
				{
					sendMessagesToClient();
				}
			});
			receiveMessagesFromClientThread.start();
			sendMessagesToClientThread.start();

			while (!stopServer)
			{
				try
				{
					Thread.sleep(1000);
				} 
				catch (InterruptedException e)
				{
					e.printStackTrace();
				}
			}
			sendMessagesToClientThread.interrupt();
			receiveMessagesFromClientThread.interrupt();
		} catch (IOException e)
		{
			e.printStackTrace();
		} 
		finally
		{
			try
			{
				sslSocket.close();
			}
			catch (IOException e)
			{
				e.printStackTrace();
			}
		}
	}

	/**
	 * Receives messages from client
	 */
	public void receiveMessagesFromClient()
	{
		try (BufferedReader bufferedReader = new BufferedReader(
				new InputStreamReader(sslSocket.getInputStream())))
		{
			String message = null;
			while ((message = bufferedReader.readLine()) != null)
			{
				receiveMessagesFromClientDout.writeUTF(message);
				receiveMessagesFromClientDout.flush();
			}
		} 
		catch (IOException e)
		{
			System.out.println("receiveMessagesFromClient: connection closed");
		}
	}

	/**
	 * Sends message to client
	 */
	public void sendMessagesToClient()
	{
		try (BufferedWriter bufferedwriter = new BufferedWriter(
				new OutputStreamWriter(sslSocket.getOutputStream())))
		{
			String message = null;
			while ((message = sendMessagesToClientDin.readUTF()) != null)
			{
				bufferedwriter.write(message + "\n");
				bufferedwriter.flush();
			}
		} 
		catch (IOException e)
		{
			System.out.println("sendMessagesToClient: connection closed");
		}
	}

	/**
	 * Prints client info
	 */
	private void receiveClientInfo()
	{
		SSLSession session = sslSocket.getSession();
		String clientInfo = "Client connected\n" + sslSocket.getInetAddress()
				+ ":" + sslSocket.getPort() + " on port "
				+ sslSocket.getLocalPort() + "\n" + "Enabled Protocols:\n"
				+ session.getProtocol() + "\n" + "Enabled Cipher Suite:\n"
				+ session.getCipherSuite() + "\n";
		System.out.println(clientInfo);
	}

	/**
	 * Stops server
	 */
	public void stopServer()
	{
		stopServer = true;
	}
}